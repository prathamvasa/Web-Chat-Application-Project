<!-- This is the WELCOME PAGE -->
<!DOCTYPE html>
<html>
<head>
<title>Welcome</title>
<style>
#submit_button_1
{
	text-align: center;
	font-family: Tahoma;
	background-color:Chartreuse;
	color:black;
	width:250px;
	height:45px;
	margin-left:20px;
	margin-top:20px;
	font-size:25px;

}
#submit_button_1:hover
{
	background-color:red;
}
#form1
{
    text-align: center;
}
#ci
{
    margin-left:530px;
}

</style>
</head>
<body style="background-color:Aqua">
	<h1 style="text-align:center">CLICK THE BUTTON BELOW TO ENTER THE CHAT APPLICATION</h1>
	<h1 style="text-align:center;color:red">WELCOME</h1>
<form action="Web_Project_Login_Page_1.php" id="form1">
	<input type="submit" value="Click To Enter" id="submit_button_1">
</form>
<br>
<br>
<img id="ci" src="chat_image.png" height="200" width="200">
</body>
</html>